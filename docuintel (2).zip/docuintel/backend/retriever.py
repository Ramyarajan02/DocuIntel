from typing import List
import numpy as np

# FAISS for dense vector search
import faiss

# BM25 for sparse keyword-based search
from rank_bm25 import BM25Okapi

# Sentence transformer for embeddings
from sentence_transformers import SentenceTransformer


# Load embedding model once at module level (reused across requests)
EMBEDDING_MODEL = SentenceTransformer("all-MiniLM-L6-v2")


class HybridRetriever:
    """
    Combines FAISS (semantic/dense) and BM25 (keyword/sparse) retrieval.
    
    - FAISS finds semantically similar chunks using vector embeddings.
    - BM25 finds chunks with exact/close keyword matches.
    - Results are merged and deduplicated (Reciprocal Rank Fusion).
    """

    def __init__(self, chunks: List[str]):
        self.chunks = chunks
        self._build_faiss_index(chunks)
        self._build_bm25_index(chunks)

    def _build_faiss_index(self, chunks: List[str]):
        """Embed all chunks and store in a FAISS flat L2 index."""
        embeddings = EMBEDDING_MODEL.encode(chunks, show_progress_bar=False)
        embeddings = np.array(embeddings).astype("float32")

        dimension = embeddings.shape[1]
        self.faiss_index = faiss.IndexFlatL2(dimension)
        self.faiss_index.add(embeddings)
        self.embeddings = embeddings

    def _build_bm25_index(self, chunks: List[str]):
        """Tokenize chunks and build BM25 index."""
        tokenized = [chunk.lower().split() for chunk in chunks]
        self.bm25 = BM25Okapi(tokenized)

    def _faiss_search(self, query: str, top_k: int) -> List[int]:
        """Return indices of top_k most semantically similar chunks."""
        query_vec = EMBEDDING_MODEL.encode([query]).astype("float32")
        distances, indices = self.faiss_index.search(query_vec, top_k)
        return indices[0].tolist()

    def _bm25_search(self, query: str, top_k: int) -> List[int]:
        """Return indices of top_k BM25 keyword-matched chunks."""
        tokens = query.lower().split()
        scores = self.bm25.get_scores(tokens)
        top_indices = np.argsort(scores)[::-1][:top_k]
        return top_indices.tolist()

    def _reciprocal_rank_fusion(self, *ranked_lists: List[int], k: int = 60) -> List[int]:
        """
        Merge multiple ranked lists using Reciprocal Rank Fusion (RRF).
        
        RRF score = sum of 1 / (k + rank) across all lists.
        Higher score = more relevant.
        """
        scores: dict[int, float] = {}
        for ranked in ranked_lists:
            for rank, doc_id in enumerate(ranked):
                scores[doc_id] = scores.get(doc_id, 0) + 1 / (k + rank + 1)
        return sorted(scores, key=scores.get, reverse=True)

    def retrieve(self, query: str, top_k: int = 5) -> List[str]:
        """
        Retrieve top_k most relevant chunks using hybrid search.
        
        Args:
            query: User's question
            top_k: Number of chunks to return
        
        Returns:
            List of relevant text chunks
        """
        faiss_results = self._faiss_search(query, top_k)
        bm25_results = self._bm25_search(query, top_k)
        fused = self._reciprocal_rank_fusion(faiss_results, bm25_results)
        
        # Return text of top_k unique chunks
        return [self.chunks[i] for i in fused[:top_k] if i < len(self.chunks)]
