import fitz  # PyMuPDF
from typing import List


def extract_text_from_pdf(file_path: str) -> str:
    """Extract raw text from all pages of a PDF."""
    doc = fitz.open(file_path)
    full_text = ""
    for page in doc:
        full_text += page.get_text()
    doc.close()
    return full_text


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 100) -> List[str]:
    """
    Split text into overlapping chunks.
    
    Args:
        text: Full document text
        chunk_size: Number of characters per chunk
        overlap: Overlap between consecutive chunks to preserve context
    
    Returns:
        List of text chunks
    """
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        start += chunk_size - overlap  # Slide window with overlap
    return chunks


def ingest_pdf(file_path: str, chunk_size: int = 500, overlap: int = 100) -> List[str]:
    """
    Full ingestion pipeline: PDF → text → chunks.
    
    Args:
        file_path: Path to the PDF file
        chunk_size: Characters per chunk
        overlap: Overlap between chunks
    
    Returns:
        List of text chunks ready for indexing
    """
    text = extract_text_from_pdf(file_path)
    chunks = chunk_text(text, chunk_size=chunk_size, overlap=overlap)
    return chunks
