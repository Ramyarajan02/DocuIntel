from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import os

from .ingestion import ingest_pdf
from .retriever import HybridRetriever
from .llm import generate_answer
from .database import init_db, save_document, load_chunks, list_documents, document_exists

app = FastAPI(title="DocuIntel API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="frontend"), name="static")

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# In-memory retriever cache — avoids rebuilding FAISS on every query
# If server restarts, chunks are reloaded from SQLite and retriever is rebuilt
retriever_cache: dict[str, HybridRetriever] = {}


@app.on_event("startup")
def startup():
    """Runs once when server starts. Creates DB tables if they don't exist."""
    init_db()
    print("✓ Database initialized (docuintel.db)")


@app.get("/")
def serve_frontend():
    return FileResponse("frontend/index.html")


@app.post("/upload")
async def upload_pdf(file: UploadFile = File(...)):
    """Upload a PDF → extract text → chunk → save to SQLite → build retriever."""
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files are supported.")

    file_path = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_path, "wb") as f:
        f.write(await file.read())

    chunks = ingest_pdf(file_path)

    # Save chunks to SQLite (persisted on disk)
    save_document(file.filename, chunks)

    # Cache retriever in memory for fast querying
    retriever_cache[file.filename] = HybridRetriever(chunks)

    return {
        "message": f"Indexed {len(chunks)} chunks from '{file.filename}'",
        "filename": file.filename
    }


class QueryRequest(BaseModel):
    filename: str
    question: str


@app.post("/query")
async def query_document(req: QueryRequest):
    """
    Query a document.
    If retriever isn't cached (e.g. after server restart),
    reload chunks from SQLite and rebuild it automatically.
    """
    if not document_exists(req.filename):
        raise HTTPException(status_code=404, detail="Document not found. Please upload it first.")

    # Rebuild retriever from DB if not in memory
    if req.filename not in retriever_cache:
        chunks = load_chunks(req.filename)
        retriever_cache[req.filename] = HybridRetriever(chunks)

    retriever = retriever_cache[req.filename]
    relevant_chunks = retriever.retrieve(req.question, top_k=5)
    answer = generate_answer(req.question, relevant_chunks)

    return {
        "answer": answer,
        "sources": relevant_chunks[:3]
    }


@app.get("/documents")
def get_documents():
    """Return all indexed documents from SQLite with metadata."""
    docs = list_documents()
    return {"documents": docs}
