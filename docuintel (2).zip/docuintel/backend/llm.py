import os
import google.generativeai as genai
from typing import List

# Configure Gemini with API key from environment
genai.configure(api_key=os.environ.get("GEMINI_API_KEY", ""))

# Use Gemini Flash for cost efficiency; swap to gemini-1.5-pro for quality
model = genai.GenerativeModel("gemini-1.5-flash")


def build_prompt(question: str, context_chunks: List[str]) -> str:
    """
    Build the RAG prompt: inject retrieved context + user question.
    
    The prompt instructs the model to:
    - Answer ONLY from provided context
    - Admit when the answer is not in the document
    - Be concise and factual
    """
    context = "\n\n---\n\n".join(context_chunks)
    
    prompt = f"""You are DocuIntel, an intelligent document assistant. 
Answer the user's question strictly based on the context extracted from the uploaded PDF document.

If the answer is not present in the context, say: "I couldn't find relevant information in the document for this question."

Do not hallucinate or use external knowledge.

CONTEXT FROM DOCUMENT:
{context}

USER QUESTION:
{question}

ANSWER:"""
    return prompt


def generate_answer(question: str, context_chunks: List[str]) -> str:
    """
    Generate a grounded answer using Gemini.
    
    Args:
        question: The user's query
        context_chunks: Retrieved relevant text chunks
    
    Returns:
        Model-generated answer string
    """
    prompt = build_prompt(question, context_chunks)
    
    try:
        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        return f"Error generating answer: {str(e)}"
