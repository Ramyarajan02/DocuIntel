"""
database.py — SQLite persistence for DocuIntel

Tables:
  documents — stores uploaded PDF metadata
  chunks    — stores all text chunks per document

SQLite is a file-based database (docuintel.db).
No installation needed. It's built into Python.
"""

import sqlite3
import os

DB_PATH = "docuintel.db"


def get_connection():
    """Open a connection to the SQLite database file."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # lets you access columns by name: row["filename"]
    return conn


def init_db():
    """
    Create tables if they don't exist yet.
    Called once when the server starts.
    """
    conn = get_connection()
    cursor = conn.cursor()

    # Table 1: one row per uploaded PDF
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            filename  TEXT UNIQUE NOT NULL,
            chunk_count INTEGER NOT NULL,
            uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Table 2: all text chunks for every document
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS chunks (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            filename  TEXT NOT NULL,
            chunk_idx INTEGER NOT NULL,
            text      TEXT NOT NULL,
            FOREIGN KEY (filename) REFERENCES documents(filename)
        )
    """)

    conn.commit()
    conn.close()


def save_document(filename: str, chunks: list[str]):
    """
    Save a document and all its chunks to SQLite.
    If the document was uploaded before, delete old chunks and re-save.
    """
    conn = get_connection()
    cursor = conn.cursor()

    # Remove old record if re-uploading same file
    cursor.execute("DELETE FROM chunks WHERE filename = ?", (filename,))
    cursor.execute("DELETE FROM documents WHERE filename = ?", (filename,))

    # Insert document metadata
    cursor.execute(
        "INSERT INTO documents (filename, chunk_count) VALUES (?, ?)",
        (filename, len(chunks))
    )

    # Insert all chunks with their index
    for idx, text in enumerate(chunks):
        cursor.execute(
            "INSERT INTO chunks (filename, chunk_idx, text) VALUES (?, ?, ?)",
            (filename, idx, text)
        )

    conn.commit()
    conn.close()


def load_chunks(filename: str) -> list[str]:
    """
    Load all chunks for a document from SQLite, in order.
    Returns empty list if document not found.
    """
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT text FROM chunks WHERE filename = ? ORDER BY chunk_idx ASC",
        (filename,)
    )
    rows = cursor.fetchall()
    conn.close()

    return [row["text"] for row in rows]


def list_documents() -> list[dict]:
    """
    Return all uploaded documents with metadata.
    """
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT filename, chunk_count, uploaded_at FROM documents ORDER BY uploaded_at DESC"
    )
    rows = cursor.fetchall()
    conn.close()

    return [dict(row) for row in rows]


def document_exists(filename: str) -> bool:
    """Check if a document is already indexed in the DB."""
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM documents WHERE filename = ?", (filename,))
    result = cursor.fetchone()
    conn.close()
    return result is not None
