/* ============================================================
   DocuIntel – Frontend Logic (Vanilla JS, no frameworks)
   Handles: drag-drop upload, chat queries, loading past docs
   ============================================================ */

const API_BASE = "http://localhost:8000";

// DOM references
const dropZone        = document.getElementById("drop-zone");
const fileInput       = document.getElementById("file-input");
const uploadStatus    = document.getElementById("upload-status");
const docBadge        = document.getElementById("doc-badge");
const docNameEl       = document.getElementById("doc-name");
const changeDocBtn    = document.getElementById("change-doc");
const docListEl       = document.getElementById("doc-list");
const chatWindow      = document.getElementById("chat-window");
const chatPlaceholder = document.getElementById("chat-placeholder");
const queryInput      = document.getElementById("query-input");
const sendBtn         = document.getElementById("send-btn");

let currentFile = null; // Currently active document filename


// ── On Page Load: fetch previously indexed docs from SQLite ──

window.addEventListener("load", fetchDocHistory);

async function fetchDocHistory() {
  try {
    const res  = await fetch(`${API_BASE}/documents`);
    const data = await res.json();

    if (!data.documents || data.documents.length === 0) {
      docListEl.innerHTML = '<p class="muted-msg">No documents indexed yet. Upload a PDF above.</p>';
      return;
    }

    // Render one row per document
    docListEl.innerHTML = "";
    data.documents.forEach((doc) => {
      const row = document.createElement("div");
      row.className = "doc-row";

      row.innerHTML = `
        <div class="doc-row-info">
          <span class="doc-row-name">${doc.filename}</span>
          <span class="doc-row-meta">${doc.chunk_count} chunks &middot; ${formatDate(doc.uploaded_at)}</span>
        </div>
        <button class="btn-ghost" onclick="selectExistingDoc('${doc.filename}')">Use this</button>
      `;

      docListEl.appendChild(row);
    });

  } catch (err) {
    docListEl.innerHTML = '<p class="muted-msg">Could not load documents. Is the server running?</p>';
  }
}

function formatDate(dateStr) {
  if (!dateStr) return "";
  const d = new Date(dateStr);
  return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function selectExistingDoc(filename) {
  // Load a previously indexed document without re-uploading
  currentFile = filename;
  docNameEl.textContent = filename;
  dropZone.classList.add("hidden");
  docBadge.classList.remove("hidden");
  uploadStatus.className = "status hidden";
  queryInput.disabled = false;
  sendBtn.disabled = false;
  queryInput.focus();
  clearChat();
  appendSystemMessage(`Loaded "${filename}" from database. Ask me anything.`);
}


// ── Upload Handling ──────────────────────────────────────────

dropZone.addEventListener("click", () => fileInput.click());

dropZone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropZone.classList.add("dragging");
});

dropZone.addEventListener("dragleave", () => {
  dropZone.classList.remove("dragging");
});

dropZone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropZone.classList.remove("dragging");
  if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
});

fileInput.addEventListener("change", () => {
  if (fileInput.files[0]) handleFile(fileInput.files[0]);
});

changeDocBtn.addEventListener("click", () => {
  currentFile = null;
  docBadge.classList.add("hidden");
  dropZone.classList.remove("hidden");
  uploadStatus.className = "status hidden";
  uploadStatus.textContent = "";
  queryInput.disabled = true;
  sendBtn.disabled = true;
  fileInput.value = "";
  clearChat();
});


async function handleFile(file) {
  if (!file.name.endsWith(".pdf")) {
    showStatus("Only PDF files are supported.", "error");
    return;
  }

  showStatus("Uploading and indexing document...", "loading");

  const formData = new FormData();
  formData.append("file", file);

  try {
    const res  = await fetch(`${API_BASE}/upload`, { method: "POST", body: formData });
    const data = await res.json();

    if (!res.ok) throw new Error(data.detail || "Upload failed");

    currentFile = data.filename;
    showStatus(`Indexed successfully.`, "success");

    dropZone.classList.add("hidden");
    docNameEl.textContent = data.filename;
    docBadge.classList.remove("hidden");

    queryInput.disabled = false;
    sendBtn.disabled = false;
    queryInput.focus();

    clearChat();
    appendSystemMessage(`"${data.filename}" is ready. ${data.message.split("from")[0].trim()} — ask me anything.`);

    // Refresh the doc history list
    fetchDocHistory();

  } catch (err) {
    showStatus(`Error: ${err.message}`, "error");
  }
}

function showStatus(msg, type) {
  uploadStatus.textContent = msg;
  uploadStatus.className   = `status ${type}`;
}


// ── Chat Handling ────────────────────────────────────────────

sendBtn.addEventListener("click", sendQuery);

queryInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendQuery(); }
});

async function sendQuery() {
  const question = queryInput.value.trim();
  if (!question || !currentFile) return;

  appendMessage("user", question);
  queryInput.value = "";
  setInputEnabled(false);

  const typingEl = appendTypingIndicator();

  try {
    const res  = await fetch(`${API_BASE}/query`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ filename: currentFile, question }),
    });
    const data = await res.json();
    typingEl.remove();

    if (!res.ok) throw new Error(data.detail || "Query failed");

    appendMessage("assistant", data.answer, data.sources);

  } catch (err) {
    typingEl.remove();
    appendMessage("assistant", `Sorry, something went wrong: ${err.message}`);
  } finally {
    setInputEnabled(true);
    queryInput.focus();
  }
}

function setInputEnabled(enabled) {
  queryInput.disabled = !enabled;
  sendBtn.disabled    = !enabled;
}


// ── Chat UI Helpers ──────────────────────────────────────────

function clearChat() {
  chatWindow.innerHTML = "";
  chatPlaceholder.style.display = "";
  chatWindow.appendChild(chatPlaceholder);
}

function hidePlaceholder() {
  chatPlaceholder.style.display = "none";
}

function appendSystemMessage(text) {
  hidePlaceholder();
  const el = document.createElement("div");
  el.style.cssText = "text-align:center;font-size:12px;color:var(--text-muted);padding:4px 0;";
  el.textContent   = text;
  chatWindow.appendChild(el);
  scrollToBottom();
}

function appendMessage(role, text, sources = []) {
  hidePlaceholder();

  const wrapper = document.createElement("div");
  wrapper.className = `message ${role}`;

  const label = document.createElement("div");
  label.className   = "message-label";
  label.textContent = role === "user" ? "You" : "DocuIntel";

  const bubble = document.createElement("div");
  bubble.className   = "message-bubble";
  bubble.textContent = text;

  wrapper.appendChild(label);
  wrapper.appendChild(bubble);

  if (role === "assistant" && sources && sources.length > 0) {
    const sourcesEl = document.createElement("div");
    sourcesEl.className = "sources";

    const sourcesLabel = document.createElement("div");
    sourcesLabel.className   = "sources-label";
    sourcesLabel.textContent = "Source Snippets";
    sourcesEl.appendChild(sourcesLabel);

    sources.slice(0, 2).forEach((chunk) => {
      const chip = document.createElement("div");
      chip.className   = "source-chip";
      chip.textContent = chunk.length > 200 ? chunk.slice(0, 200) + "…" : chunk;
      sourcesEl.appendChild(chip);
    });

    wrapper.appendChild(sourcesEl);
  }

  chatWindow.appendChild(wrapper);
  scrollToBottom();
}

function appendTypingIndicator() {
  hidePlaceholder();
  const wrapper = document.createElement("div");
  wrapper.className = "message assistant";

  const label = document.createElement("div");
  label.className   = "message-label";
  label.textContent = "DocuIntel";

  const dots = document.createElement("div");
  dots.className = "typing-indicator";
  dots.innerHTML = "<span></span><span></span><span></span>";

  wrapper.appendChild(label);
  wrapper.appendChild(dots);
  chatWindow.appendChild(wrapper);
  scrollToBottom();
  return wrapper;
}

function scrollToBottom() {
  chatWindow.scrollTop = chatWindow.scrollHeight;
}
