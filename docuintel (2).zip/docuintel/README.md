# DocuIntel – RAG-Based PDF Chatbot

Upload any PDF and ask natural language questions about it.
Powered by Hybrid Retrieval (FAISS + BM25) + Google Gemini, with SQLite for persistence.

---

## Tech Stack

| Layer           | Technology                        |
|-----------------|-----------------------------------|
| Backend API     | FastAPI                           |
| PDF Parsing     | PyMuPDF (fitz)                    |
| Dense Retrieval | FAISS + sentence-transformers     |
| Sparse Retrieval| BM25 (rank-bm25)                  |
| Fusion          | Reciprocal Rank Fusion (RRF)      |
| Database        | SQLite (built into Python)        |
| LLM             | Google Gemini 1.5 Flash           |
| Frontend        | HTML + CSS + Vanilla JS           |

---

## Setup & Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Add your Gemini API key
Get a FREE key at: https://aistudio.google.com/app/apikey

**Mac/Linux:**
```bash
export GEMINI_API_KEY="paste-your-key-here"
```

**Windows (Command Prompt):**
```
set GEMINI_API_KEY=paste-your-key-here
```

**Windows (PowerShell):**
```
$env:GEMINI_API_KEY="paste-your-key-here"
```

### 3. Run the server
```bash
python run.py
```

### 4. Open browser
```
http://localhost:8000
```

---

## Project Structure

```
docuintel/
├── backend/
│   ├── __init__.py
│   ├── main.py        ← FastAPI routes (/upload, /query, /documents)
│   ├── ingestion.py   ← PDF text extraction + chunking
│   ├── retriever.py   ← FAISS + BM25 hybrid retriever
│   ├── llm.py         ← Gemini prompt builder + API call
│   └── database.py    ← SQLite: save/load chunks, list documents
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── uploads/           ← Uploaded PDFs saved here
├── docuintel.db       ← SQLite DB file (auto-created on first run)
├── requirements.txt
├── run.py
└── README.md
```

---

## How the Database Works

SQLite is a file-based database. When you run the server, it creates `docuintel.db`
automatically. No setup, no password, no server needed — it's just a file.

### Two tables:

**documents** — one row per uploaded PDF
```
id | filename      | chunk_count | uploaded_at
1  | report.pdf    | 142         | 2025-06-01 10:30:00
```

**chunks** — all text chunks for every document
```
id | filename   | chunk_idx | text
1  | report.pdf | 0         | "This report covers Q3 results..."
2  | report.pdf | 1         | "Revenue increased by 12% compared..."
```

### What happens when server restarts?
- Chunks are already in SQLite
- When you query, the code checks if retriever is in memory cache
- If not (after restart), it loads chunks from SQLite and rebuilds FAISS + BM25
- You don't need to re-upload — just click "Use this" on the previous docs list

---

## Interview Q&A

**Q: Why SQLite and not PostgreSQL or MongoDB?**
> SQLite is perfect for a prototype/intern project. Zero setup, built into Python, stores everything in one file. For production with multiple users, I'd upgrade to PostgreSQL with pgvector for native vector support.

**Q: What is RAG?**
> Retrieval Augmented Generation. Instead of asking the LLM to answer from its training data, you first retrieve relevant text from your own documents, then pass that as context to the LLM. This grounds the answer in real data and prevents hallucination.

**Q: Why FAISS + BM25 together?**
> FAISS uses vector embeddings — great for semantic/meaning-based search. BM25 is keyword-based — great for exact term matches. Together they cover both cases. A question like "what is EBITDA?" benefits from FAISS (semantics), while "EBITDA Q3 2023 value" benefits from BM25 (exact keywords).

**Q: What is Reciprocal Rank Fusion (RRF)?**
> It merges two ranked lists without needing to tune weights. Each result gets a score of 1/(k + rank). Results appearing high in both lists score highest. k=60 is standard. It works because FAISS distances and BM25 scores are on completely different scales — you can't add them directly, but you can use their rank positions.

**Q: What embedding model did you use?**
> all-MiniLM-L6-v2 from sentence-transformers. 22MB, runs on CPU, produces 384-dimensional vectors. Good balance of speed and quality for a prototype.

**Q: What chunking strategy?**
> Fixed-size sliding window: 500 characters per chunk with 100-character overlap. Overlap preserves context at chunk boundaries so an answer split across two chunks isn't lost.

**Q: How would you scale this?**
> Persist FAISS index to disk with faiss.write_index(). Use PostgreSQL + pgvector instead of SQLite. Add Redis to cache frequent queries. Deploy with Docker + Gunicorn.
